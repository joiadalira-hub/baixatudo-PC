"""BaixaTudo para PC — baixa vídeos/músicas e remove legendas."""
import sys

if sys.stdout is None or sys.stderr is None:
    # No .exe sem console não existe stdout/stderr: manda tudo para um arquivo de log
    from baixatudo import paths
    _log = open(paths.app_dir() / "log.txt", "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _log
    sys.stderr = sys.stderr or _log

from baixatudo import server  # noqa: E402

if __name__ == "__main__":
    server.main(open_ui="--sem-janela" not in sys.argv)
