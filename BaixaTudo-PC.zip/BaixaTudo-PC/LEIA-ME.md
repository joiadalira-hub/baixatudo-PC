# BaixaTudo para PC (Windows)

A mesma ideia do app de Android, agora no computador:

- **Baixar**: cole o link (YouTube, Shorts, Instagram, TikTok, Facebook e centenas de outros
  sites), escolha MP4 / MP3 / M4A / Original e a qualidade. Dá para colar vários links
  seguidos: eles baixam ao mesmo tempo. Ao voltar para a janela com um link copiado, ele
  já aparece no campo.
- **Depois de baixar**: Abrir, Mostrar na pasta (abre o Explorador com o arquivo
  selecionado) ou Remover legenda.
- **Remover legenda**: escolha um vídeo, arraste a linha do tempo até um ponto com
  legenda, marque a legenda com o retângulo (arraste para mover, puxe os cantos para
  ajustar, ou use as setas do teclado; Shift + setas muda o tamanho), veja a prévia e
  clique em Remover legenda. O arquivo novo "… (sem legenda).mp4" fica na mesma pasta.
  - **Precisa**: detecta só as letras paradas na tela e recupera o fundo real de outros
    quadros, conferindo cada pedaço copiado (evita "fantasmas").
  - **Forte**: pega também textos fracos, finos ou com sombra.
  - **Rápida**: apaga o retângulo com um borrão.
  - **Qualidade do arquivo**: "Máxima" gera um arquivo maior, bom para levar ao Premiere.

Tudo roda no seu computador. Nada é enviado para a internet além do próprio download.

## Como gerar o programa (pelo GitHub, sem instalar nada)

No mesmo repositório do app Android (ou num novo):

1. **Add file → Upload files** → envie o `BaixaTudo-PC.zip` → **Commit changes**.
2. **Add file → Create new file** → nome `.github/workflows/build-pc.yml` → cole o conteúdo
   do arquivo `build-pc.yml` → **Commit changes**.
3. Aba **Actions** → "Gerar programa para Windows". Leva uns 10 minutos. O próprio GitHub
   liga o programa e testa um download e uma remoção de legenda antes de terminar.
4. No ✅, desça até **Artifacts** e baixe **BaixaTudo-Windows**.
5. No PC: extraia o zip numa pasta (ex.: `C:\BaixaTudo`) e abra **BaixaTudo.exe**.

Na primeira vez, o Windows pode mostrar "O Windows protegeu o computador" (o programa não
tem assinatura digital paga). Clique em **Mais informações → Executar assim mesmo**.

A janela usa o Microsoft Edge em modo aplicativo (já vem no Windows 10/11). Ao fechar a
janela, o programa encerra sozinho; se houver um download ou remoção em andamento, ele
termina o trabalho antes de fechar.

## Para rodar direto do código (opcional)

Precisa de Python 3.11+ e FFmpeg + yt-dlp instalados (ou dentro de uma pasta `bin/` ao
lado do `main.py`):

```
pip install -r requirements.txt
python main.py
```

## Atualizar o motor

Os sites mudam com frequência. Se um download começar a falhar, clique em
**Atualizar motor** no canto inferior esquerdo.

Baixe apenas conteúdo que você tem direito de baixar (seu próprio, domínio público,
Creative Commons ou com autorização do autor).
