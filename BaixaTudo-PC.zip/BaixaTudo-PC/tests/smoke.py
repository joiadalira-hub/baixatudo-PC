"""
Teste de fumaça do programa já empacotado (roda no GitHub Actions, no Windows).
Liga o .exe sem janela, baixa um vídeo servido localmente, remove a legenda dele
e confere se os arquivos saíram.

uso: python tests/smoke.py dist/BaixaTudo/BaixaTudo.exe dist/BaixaTudo/_internal/bin
"""
import http.server
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
exe, bindir = sys.argv[1], Path(sys.argv[2])
ffmpeg = str(bindir / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg"))
work = Path(tempfile.mkdtemp())
www, out = work / "www", work / "saida"
www.mkdir(); out.mkdir()

# vídeo de teste com legenda "queimada" e som
# a fonte é copiada para a pasta de trabalho: caminho sem "C:" (os dois-pontos confundem o filtro)
import shutil
font = "C:/Windows/Fonts/arialbd.ttf" if os.name == "nt" else "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
shutil.copy(font, work / "fonte.ttf")
subprocess.run([ffmpeg, "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=720x1280:d=4:r=30",
                "-f", "lavfi", "-i", "sine=f=440:d=4", "-vf",
                "drawtext=fontfile=fonte.ttf:text='Legenda de teste':fontsize=56:fontcolor=white:"
                "borderw=5:bordercolor=black:x=(w-tw)/2:y=h*0.75",
                "-c:v", "libx264", "-c:a", "aac", "-shortest", str(www / "teste.mp4")], check=True, cwd=work)

# vídeo mais longo (40 s, quadro-chave a cada 2 s) para testar o corte
subprocess.run([ffmpeg, "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=426x240:d=40:r=30",
                "-f", "lavfi", "-i", "sine=f=330:d=40", "-c:v", "libx264", "-g", "60",
                "-c:a", "aac", "-shortest", str(www / "longo.mp4")], check=True, cwd=work)


def duration(path, kind):
    r = subprocess.run([ffmpeg, "-hide_banner", "-i", str(path), "-map", f"0:{kind}:0", "-c", "copy", "-f", "null", "-"],
                       capture_output=True)
    t = re.findall(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr.decode("utf-8", "replace"))
    if not t:
        print("   ffmpeg não leu a faixa", kind, "de", path, "\n", r.stderr.decode("utf-8", "replace")[-1500:])
        return 0.0
    h, m, x = t[-1]
    return int(h) * 3600 + int(m) * 60 + float(x)


srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8799),
                                      lambda *a: http.server.SimpleHTTPRequestHandler(*a, directory=str(www)))
threading.Thread(target=srv.serve_forever, daemon=True).start()

app = subprocess.Popen([exe, "--sem-janela"])
base = "http://127.0.0.1:47815"
for _ in range(60):
    try:
        urllib.request.urlopen(base + "/api/hello", timeout=1)
        break
    except Exception:
        time.sleep(1)
else:
    sys.exit("o programa não respondeu")

token = re.search(r'BT_TOKEN = "([^"]+)"', urllib.request.urlopen(base + "/").read().decode()).group(1)


def api(path, body=None):
    req = urllib.request.Request(base + path, data=None if body is None else json.dumps(body).encode(),
                                 headers={"X-BT-Token": token, "Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=120).read())


def wait(job_id):
    for _ in range(600):
        j = next(j for j in api("/api/jobs") if j["id"] == job_id)
        if j["status"] != "running":
            return j
        time.sleep(0.5)
    sys.exit("demorou demais")


try:
    print("motor:", api("/api/engine"))
    for fmt, q in (("mp4", "Melhor"), ("mp3", "192 kbps")):
        j = wait(api("/api/download", {"url": "http://127.0.0.1:8799/teste.mp4", "format": fmt,
                                       "quality": q, "folder": str(out)})["id"])
        print(fmt, j["status"], j["message"], j["files"], j.get("detail"))
        assert j["status"] == "done", j
    # corte rápido (sem recodificar) e corte exato
    for exact in (False, True):
        jid = api("/api/download", {"url": "http://127.0.0.1:8799/longo.mp4", "format": "mp4", "quality": "Melhor",
                                    "folder": str(out), "cut": [10, 25], "exact": exact})["id"]
        msgs = set()
        for _ in range(600):
            j = next(j for j in api("/api/jobs") if j["id"] == jid)
            msgs.add(j["message"])
            if j["status"] != "running":
                break
            time.sleep(0.3)
        print("corte", "exato" if exact else "rápido", j["status"], j["files"], j.get("detail"))
        print("   etapas:", sorted(msgs))
        assert j["status"] == "done", j
        f = j["files"][0]
        assert "(0m10s a 0m25s)" in f, f
        dv, da = duration(f, "v"), duration(f, "a")
        print(f"   vídeo {dv:.2f}s, áudio {da:.2f}s")
        assert da >= 13, "o áudio veio incompleto"
        if exact:
            assert abs(dv - 15) < 0.3, dv
        else:
            assert 13 <= dv <= 19, dv
    j = wait(api("/api/download", {"url": "http://127.0.0.1:8799/longo.mp4", "format": "mp3", "quality": "192 kbps",
                                   "folder": str(out), "cut": [5, 12]})["id"])
    print("mp3 cortado", j["status"], j["files"], j.get("detail"))
    assert j["status"] == "done" and j["files"][0].endswith(".mp3"), j
    print("   áudio", duration(j["files"][0], "a"))
    video = str(out / "teste.mp4")
    info = api("/api/video/info", {"path": video})
    print("info", info)
    box = [0.02, 0.70, 0.98, 0.84]
    pv = api("/api/video/preview", {"path": video, "box": box, "mode": "precisa", "t": 2.0})
    assert pv["image"].startswith("data:image/jpeg"), "prévia falhou"
    j = wait(api("/api/video/remove", {"path": video, "box": box, "mode": "precisa"})["id"])
    print("remover", j["status"], j["message"], j["files"])
    assert j["status"] == "done", j
    assert Path(j["files"][0]).stat().st_size > 10000
    print("TUDO OK:", sorted(p.name for p in out.iterdir()))
finally:
    app.kill()
    srv.shutdown()
