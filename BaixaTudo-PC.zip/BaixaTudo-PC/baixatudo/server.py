"""
Servidor local (só 127.0.0.1) que liga a interface HTML ao motor.
A janela é o Edge/Chrome em "modo aplicativo" (sem barra de endereço).
"""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import secrets
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import cv2

from . import __version__, download, media, paths, remover

WEB = Path(__file__).resolve().parent / "web"
if getattr(sys, "frozen", False):
    WEB = Path(getattr(sys, "_MEIPASS", ".")) / "baixatudo" / "web"


# ------------------------------------------------------------------ tarefas

class Job:
    def __init__(self, kind: str, title: str):
        self.id = secrets.token_hex(4)
        self.kind, self.title = kind, title
        self.status = "running"          # running | done | error | cancelled
        self.progress = -1.0
        self.message = "Começando…"
        self.files: list[str] = []
        self.error = ""
        self.detail = ""
        self.created = time.time()
        self.cancel_fn = lambda: None
        self.extra: dict = {}

    def to_json(self):
        return {"id": self.id, "kind": self.kind, "title": self.title, "status": self.status,
                "progress": self.progress, "message": self.message, "files": self.files,
                "error": self.error, "detail": self.detail, "extra": self.extra}


JOBS: dict[str, Job] = {}
LOCK = threading.Lock()
LAST_PING = time.time()
BYE_AT = 0.0


def running_jobs():
    return [j for j in JOBS.values() if j.status == "running"]


def start_download(body):
    url = (body.get("url") or "").strip()
    fmt = body.get("format", "mp4")
    folder = body.get("folder") or paths.default_download_dir()
    paths.save_config(folder=folder, format=fmt, quality=body.get("quality", ""),
                      removeSubs=bool(body.get("removeSubs")))
    job = Job("download", url)
    job.extra = {"format": fmt, "removeSubs": bool(body.get("removeSubs")) and fmt in ("mp4", "original")}
    d = download.Download(url, fmt, body.get("quality", ""), folder)
    job.cancel_fn = d.cancel

    def work():
        try:
            def prog(p, m):
                job.progress, job.message = p, m
            job.files = d.run(prog)
            job.title = Path(job.files[0]).name
            job.status, job.progress, job.message = "done", 100, "Concluído"
        except Exception as e:
            if d.cancelled:
                job.status, job.message = "cancelled", "Cancelado"
            else:
                job.status, job.error = "error", str(e)
                job.detail = getattr(e, "detail", "")
                job.message = str(e)
    with LOCK:
        JOBS[job.id] = job
    threading.Thread(target=work, daemon=True).start()
    return job


def _unique(path: Path) -> Path:
    if not path.exists():
        return path
    i = 2
    while True:
        p = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not p.exists():
            return p
        i += 1


def _box(info, b):
    l, t, r, bt = (float(v) for v in b)
    return remover.Box(int(l * info.width), int(t * info.height), int(r * info.width), int(bt * info.height))


def start_remove(body):
    src = body["path"]
    info = media.probe(src)
    box = _box(info, body["box"])
    mode = body.get("mode", remover.PRECISE)
    crf = {"alta": 16, "maxima": 12, "menor": 20}.get(body.get("quality", "alta"), 16)
    folder = Path(body.get("folder") or Path(src).parent)
    out = _unique(folder / f"{Path(src).stem} (sem legenda).mp4")
    paths.save_config(subMode=mode, subBox=body["box"], subQuality=body.get("quality", "alta"))
    job = Job("remove", out.name)
    rj = remover.RemoveJob(info, box, mode, str(out), crf=crf)
    job.cancel_fn = rj.cancel

    def work():
        try:
            def prog(p, m):
                job.progress, job.message = p, m
            rj.run(prog)
            job.files = [str(out)]
            job.status, job.progress, job.message = "done", 100, "Concluído"
        except remover.Cancelled:
            job.status, job.message = "cancelled", "Cancelado"
            try:
                out.unlink(missing_ok=True)
            except Exception:
                pass
        except Exception as e:
            job.status, job.error, job.message = "error", str(e), "Falhou: " + str(e)
            try:
                out.unlink(missing_ok=True)
            except Exception:
                pass
    with LOCK:
        JOBS[job.id] = job
    threading.Thread(target=work, daemon=True).start()
    return job


# ------------------------------------------------------------- diálogos nativos

def _powershell(script: str) -> str:
    r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", script],
                       capture_output=True, **paths.popen_kwargs())
    return r.stdout.decode("utf-8", "replace").strip()


def pick_folder(initial: str = "") -> str | None:
    if paths.IS_WIN:
        init = initial.replace("'", "''")
        s = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8;Add-Type -AssemblyName System.Windows.Forms;"
             "$d=New-Object System.Windows.Forms.FolderBrowserDialog;$d.Description='Onde salvar os arquivos';"
             f"$d.SelectedPath='{init}';$d.ShowNewFolderButton=$true;"
             "$f=New-Object System.Windows.Forms.Form;$f.TopMost=$true;"
             "if($d.ShowDialog($f) -eq 'OK'){$d.SelectedPath}")
        return _powershell(s) or None
    return _zenity(["--file-selection", "--directory"])


def pick_video() -> str | None:
    if paths.IS_WIN:
        s = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8;Add-Type -AssemblyName System.Windows.Forms;"
             "$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Title='Escolha o vídeo';"
             "$d.Filter='Vídeos|*.mp4;*.mov;*.mkv;*.webm;*.m4v;*.avi|Todos os arquivos|*.*';"
             "$f=New-Object System.Windows.Forms.Form;$f.TopMost=$true;"
             "if($d.ShowDialog($f) -eq 'OK'){$d.FileName}")
        return _powershell(s) or None
    return _zenity(["--file-selection", "--file-filter=*.mp4 *.mov *.mkv *.webm"])


def _zenity(args):
    try:
        r = subprocess.run(["zenity"] + args, capture_output=True, timeout=600)
        return r.stdout.decode().strip() or None
    except Exception:
        return None


def clipboard_text() -> str:
    if paths.IS_WIN:
        return _powershell("[Console]::OutputEncoding=[Text.Encoding]::UTF8;Get-Clipboard -Raw")
    for cmd in (["xclip", "-o", "-selection", "clipboard"], ["wl-paste"]):
        try:
            return subprocess.run(cmd, capture_output=True, timeout=3).stdout.decode()
        except Exception:
            pass
    return ""


# ------------------------------------------------------------------- HTTP

def _jpeg(img, maxside=1280):
    h, w = img.shape[:2]
    s = min(1.0, maxside / max(h, w))
    if s < 1:
        img = cv2.resize(img, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return buf.tobytes()


class Handler(BaseHTTPRequestHandler):
    server_version = "BaixaTudo"

    def log_message(self, *a):
        pass

    # respostas
    def _send(self, code, body: bytes, ctype="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def _guard(self) -> bool:
        # só aceita chamadas da própria janela (evita que sites externos usem a API)
        if self.headers.get("X-BT-Token") != TOKEN:
            self._json({"error": "forbidden"}, 403)
            return False
        return True

    def do_GET(self):
        global LAST_PING
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        try:
            if u.path == "/api/hello":
                return self._json({"app": "BaixaTudo"})
            if u.path in ("/", "/index.html"):
                html = (WEB / "index.html").read_text("utf-8").replace("__TOKEN__", TOKEN)
                return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
            if u.path.startswith("/static/"):
                f = (WEB / u.path[len("/static/"):]).resolve()
                if WEB.resolve() in f.parents and f.is_file():
                    return self._send(200, f.read_bytes(), mimetypes.guess_type(str(f))[0] or "application/octet-stream")
                return self._send(404, b"not found", "text/plain")
            if u.path == "/api/frame":
                if q.get("k", [""])[0] != TOKEN:
                    return self._send(403, b"", "text/plain")
                img = media.grab_frame(q["path"][0], float(q.get("t", ["0"])[0]))
                if img is None:
                    return self._send(404, b"", "text/plain")
                return self._send(200, _jpeg(img, int(q.get("w", ["1280"])[0])), "image/jpeg")
            if not self._guard():
                return
            if u.path == "/api/state":
                LAST_PING = time.time()
                c = paths.config()
                return self._json({
                    "version": __version__, "formats": download.FORMATS,
                    "folder": c.get("folder") or paths.default_download_dir(),
                    "format": c.get("format", "mp4"), "quality": c.get("quality", ""),
                    "removeSubs": c.get("removeSubs", False),
                    "subMode": c.get("subMode", remover.PRECISE), "subBox": c.get("subBox"),
                    "subQuality": c.get("subQuality", "alta"),
                })
            if u.path == "/api/jobs":
                LAST_PING = time.time()
                with LOCK:
                    jobs = sorted(JOBS.values(), key=lambda j: -j.created)
                return self._json([j.to_json() for j in jobs])
            if u.path == "/api/engine":
                return self._json({"version": download.engine_version()})
            self._json({"error": "not found"}, 404)
        except Exception as e:
            traceback.print_exc()
            self._json({"error": str(e)}, 500)

    def do_POST(self):
        global BYE_AT
        u = urllib.parse.urlparse(self.path)
        if u.path == "/api/bye":
            if urllib.parse.parse_qs(u.query).get("k", [""])[0] == TOKEN:
                BYE_AT = time.time()
            return self._send(204, b"", "text/plain")
        if not self._guard():
            return
        try:
            b = self._body()
            p = u.path
            if p == "/api/download":
                return self._json(start_download(b).to_json())
            if p == "/api/cancel":
                j = JOBS.get(b.get("id"))
                if j:
                    j.cancel_fn()
                return self._json({"ok": True})
            if p == "/api/clear":
                with LOCK:
                    for k in [k for k, j in JOBS.items() if j.status != "running"]:
                        del JOBS[k]
                return self._json({"ok": True})
            if p == "/api/update":
                return self._json({"message": download.update_engine()})
            if p == "/api/pick-folder":
                return self._json({"path": pick_folder(b.get("initial", ""))})
            if p == "/api/pick-video":
                return self._json({"path": pick_video()})
            if p == "/api/clipboard":
                return self._json({"text": clipboard_text()})
            if p == "/api/open":
                paths.open_file(b["path"]); return self._json({"ok": True})
            if p == "/api/show":
                paths.show_in_folder(b["path"]); return self._json({"ok": True})
            if p == "/api/video/info":
                i = media.probe(b["path"])
                return self._json({"path": i.path, "name": Path(i.path).name, "width": i.width,
                                   "height": i.height, "fps": i.fps, "duration": i.duration})
            if p == "/api/video/preview":
                info = media.probe(b["path"])
                img = remover.preview(info, _box(info, b["box"]), b.get("mode", remover.PRECISE), float(b.get("t", 0)))
                return self._json({"image": "data:image/jpeg;base64," + base64.b64encode(_jpeg(img)).decode()})
            if p == "/api/video/remove":
                return self._json(start_remove(b).to_json())
            self._json({"error": "not found"}, 404)
        except Exception as e:
            traceback.print_exc()
            self._json({"error": str(e)}, 500)


TOKEN = secrets.token_urlsafe(16)


# ------------------------------------------------------------------- janela

def _browser_candidates():
    if paths.IS_WIN:
        roots = [os.environ.get(k, "") for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
        rel = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe",
               r"BraveSoftware\Brave-Browser\Application\brave.exe"]
        return [os.path.join(r, x) for x in rel for r in roots if r]
    if sys.platform == "darwin":
        return ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    return ["/usr/bin/microsoft-edge", "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser"]


def open_window(url: str):
    """Abre a interface numa janela própria. Devolve o processo (ou None se caiu no navegador padrão)."""
    profile = paths.app_dir() / "janela"
    for exe in _browser_candidates():
        if os.path.exists(exe):
            return subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile}",
                                     "--window-size=1180,860", "--no-first-run", "--no-default-browser-check",
                                     "--disable-features=Translate,msEdgeSidebarV2"])
    import webbrowser
    webbrowser.open(url)
    return None


def main(open_ui: bool = True, port: int = 47815):
    # Já tem um aberto? Só mostra a janela dele.
    import urllib.request
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/hello", timeout=1) as r:
            if json.loads(r.read()).get("app") == "BaixaTudo":
                info = json.loads((paths.app_dir() / "running.json").read_text())
                open_window(info["url"])
                return
    except Exception:
        pass

    try:
        httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except OSError:
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    url = f"http://127.0.0.1:{httpd.server_address[1]}/"
    (paths.app_dir() / "running.json").write_text(json.dumps({"url": url}))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    print("BaixaTudo em", url, flush=True)

    if open_ui:
        open_window(url)

    # Fecha sozinho quando a janela é fechada (a janela avisa que está viva a cada 2 s).
    # Se houver download/remoção em andamento, espera terminar antes de sair.
    global LAST_PING
    LAST_PING = time.time()
    while True:
        time.sleep(2)
        if not open_ui or running_jobs():
            continue
        now = time.time()
        closed = BYE_AT and now - BYE_AT > 6 and LAST_PING < BYE_AT   # fechou e não recarregou
        silent = now - LAST_PING > 300    # janela sumiu sem avisar (minimizada não conta: ela ainda pinga)
        if closed or silent:
            break
    httpd.shutdown()
