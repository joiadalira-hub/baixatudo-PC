"""Downloads com o yt-dlp (executável separado, com progresso lido linha a linha)."""
from __future__ import annotations

import os
import re
import subprocess
import threading
from pathlib import Path
from typing import Callable

from . import paths

FORMATS = {
    "mp4": ["Melhor", "2160p", "1440p", "1080p", "720p", "480p", "360p"],
    "mp3": ["320 kbps", "256 kbps", "192 kbps", "128 kbps"],
    "m4a": [],
    "original": [],
}

_PROG = "BTP"
_FILE = "BTFILE"


def build_args(url: str, fmt: str, quality: str, folder: str, temp: str) -> list[str]:
    a = [
        "--no-playlist", "--no-mtime", "--newline", "--progress",
        "--encoding", "utf-8",
        # Baixa numa pasta só deste download; depois o resultado é movido para a pasta do
        # usuário. Assim o yt-dlp nunca reaproveita nem apaga arquivos que já estão lá
        # (ex.: baixar o MP3 de um vídeo cujo MP4 já foi baixado).
        "-P", f"home:{folder}", "-P", f"temp:{temp}",
        "-o", "%(title).150B.%(ext)s",
        "--ffmpeg-location", paths.ffmpeg(),
        "--progress-template",
        f"download:{_PROG} %(progress.downloaded_bytes)s %(progress.total_bytes)s "
        f"%(progress.total_bytes_estimate)s %(progress.eta)s %(progress.speed)s",
        "--print", f"after_move:{_FILE} %(filepath)s",
    ]
    d = paths.deno()
    if d:
        a += ["--js-runtimes", f"deno:{d}"]
    if fmt == "mp4":
        h = re.sub(r"\D", "", quality)
        res = f"res:{h}" if h else "res"
        # H.264 + AAC: abre em qualquer editor (Premiere, CapCut…) e player
        a += ["-f", "bv*+ba/b", "-S", f"{res},vcodec:h264,acodec:m4a",
              "--merge-output-format", "mp4", "--remux-video", "mp4"]
    elif fmt == "mp3":
        k = re.sub(r"\D", "", quality) or "192"
        a += ["-f", "bestaudio/best", "-x", "--audio-format", "mp3", "--audio-quality", f"{k}K", "--embed-metadata"]
    elif fmt == "m4a":
        a += ["-f", "bestaudio[ext=m4a]/bestaudio/best", "-x", "--audio-format", "m4a", "--embed-metadata"]
    else:
        a += ["-f", "bv*+ba/b"]
    return a + ["--", url]


def friendly_error(text: str) -> str:
    m = text.lower()
    if "unsupported url" in m:
        return "Esse link não é suportado."
    if "sign in" in m or "login" in m or "cookies" in m:
        return "O site exige login para esse conteúdo (privado, restrito por idade ou bloqueio temporário)."
    if "429" in m or "rate-limit" in m or "too many requests" in m:
        return "O site bloqueou temporariamente. Tente de novo em alguns minutos."
    if "private" in m:
        return "Esse conteúdo é privado."
    if "unable to resolve" in m or "getaddrinfo" in m or "timed out" in m or "network" in m:
        return "Problema de conexão. Verifique sua internet."
    if "requested format is not available" in m:
        return "Essa qualidade não está disponível. Tente \"Melhor\" ou outro formato."
    return "Não foi possível baixar. Clique em \"Atualizar motor\" e tente de novo."


def _fmt_eta(s):
    s = int(s)
    return f"{s // 60}min {s % 60:02d}s" if s >= 60 else f"{s}s"


def _fmt_speed(b):
    return f"{b / 1048576:.1f} MB/s" if b >= 1048576 else f"{b / 1024:.0f} KB/s"


class Download:
    """Um download. run() bloqueia; chame numa thread. cancel() interrompe."""

    def __init__(self, url, fmt, quality, folder):
        self.url, self.fmt, self.quality, self.folder = url, fmt, quality, folder
        self.proc: subprocess.Popen | None = None
        self.cancelled = False
        self.files: list[str] = []

    def cancel(self):
        self.cancelled = True
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.kill()
            except Exception:
                pass

    def run(self, progress: Callable[[float, str], None]) -> list[str]:
        import shutil, uuid
        Path(self.folder).mkdir(parents=True, exist_ok=True)
        job_dir = Path(paths.temp_dir()) / uuid.uuid4().hex[:10]
        (job_dir / "partes").mkdir(parents=True)
        try:
            files = self._run(progress, str(job_dir), str(job_dir / "partes"))
            final = []
            for f in files:
                dest = _unique(Path(self.folder) / Path(f).name)
                shutil.move(f, dest)
                final.append(str(dest))
            return final
        finally:
            shutil.rmtree(job_dir, ignore_errors=True)

    def _run(self, progress, home: str, temp: str) -> list[str]:
        cmd = paths.ytdlp() + build_args(self.url, self.fmt, self.quality, home, temp)
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     stdin=subprocess.DEVNULL, env=env, **paths.popen_kwargs())
        err_lines: list[str] = []

        def drain():
            for raw in iter(self.proc.stderr.readline, b""):
                line = raw.decode("utf-8", "replace").rstrip()
                if line:
                    err_lines.append(line)
                    del err_lines[:-60]
        t = threading.Thread(target=drain, daemon=True); t.start()

        progress(-1, "Analisando o link…")
        parts = 0
        last_pct = 0.0
        for raw in iter(self.proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith(_PROG):
                f = line.split()[1:]
                num = lambda v: float(v) if v not in ("NA", "None", "") else 0.0
                done, total, est, eta, speed = (num(x) for x in (f + ["NA"] * 5)[:5])
                tot = total or est
                if tot:
                    pct = min(100.0, done * 100 / tot)
                    if pct + 5 < last_pct:     # começou a 2ª parte (áudio depois do vídeo)
                        parts += 1
                    last_pct = pct
                    msg = f"Baixando{' o áudio' if parts else ''}… {pct:.0f}%"
                    if speed:
                        msg += f"  •  {_fmt_speed(speed)}"
                    if eta:
                        msg += f"  •  faltam {_fmt_eta(eta)}"
                    progress(pct if not parts else pct, msg)
                    if pct >= 100:
                        progress(-1, "Convertendo / juntando…")
            elif line.startswith(_FILE):
                self.files.append(line[len(_FILE):].strip())
        code = self.proc.wait()
        t.join(2)
        if self.cancelled:
            raise RuntimeError("Download cancelado.")
        if code != 0:
            detail = next((l for l in reversed(err_lines) if "ERROR" in l), err_lines[-1] if err_lines else "")
            e = RuntimeError(friendly_error(detail))
            e.detail = detail  # type: ignore[attr-defined]
            raise e
        files = [f for f in self.files if os.path.exists(f)]
        if not files:
            raise RuntimeError("O download terminou, mas nenhum arquivo foi encontrado.")
        return files


def _unique(p: Path) -> Path:
    if not p.exists():
        return p
    i = 2
    while True:
        q = p.with_name(f"{p.stem} ({i}){p.suffix}")
        if not q.exists():
            return q
        i += 1


def update_engine() -> str:
    cmd = paths.ytdlp()
    if len(cmd) > 1:   # rodando como módulo python (modo de desenvolvimento)
        return "Atualização automática só funciona na versão instalada."
    r = subprocess.run(cmd + ["-U"], capture_output=True, **paths.popen_kwargs())
    out = (r.stdout + r.stderr).decode("utf-8", "replace")
    v = subprocess.run(cmd + ["--version"], capture_output=True, **paths.popen_kwargs()).stdout.decode().strip()
    if "up to date" in out.lower() or "up-to-date" in out.lower():
        return f"O motor já está na versão mais recente ({v})."
    if r.returncode == 0:
        return f"Motor atualizado (versão {v})."
    return "Falha ao atualizar: " + (out.strip().splitlines() or ["erro"])[-1]


def engine_version() -> str:
    try:
        r = subprocess.run(paths.ytdlp() + ["--version"], capture_output=True, timeout=30, **paths.popen_kwargs())
        return r.stdout.decode().strip()
    except Exception:
        return "?"
