"""Downloads com o yt-dlp (executável separado, com progresso lido linha a linha)."""
from __future__ import annotations

import os
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable

from . import paths

FORMATS = {
    "mp4": ["Melhor", "2160p", "1440p", "1080p", "720p", "480p", "360p"],
    "mp3": ["320 kbps", "256 kbps", "192 kbps", "128 kbps"],
    "m4a": [],
    "original": [],
}

_PROG = "BTP"
_FILE = "BTFILE"


def _num(s: float) -> str:
    return f"{s:.2f}"


def clock(s: float) -> str:
    """83.5 -> "1:23" """
    t = int(s)
    return f"{t // 3600}:{t // 60 % 60:02d}:{t % 60:02d}" if t >= 3600 else f"{t // 60}:{t % 60:02d}"


def tag(s: float) -> str:
    """Para nome de arquivo (sem ":"): 83 -> "1m23s" """
    t = int(s)
    return f"{t // 3600}h{t // 60 % 60:02d}m{t % 60:02d}s" if t >= 3600 else f"{t // 60}m{t % 60:02d}s"


def _cover_art() -> list[str]:
    """Capa do vídeo dentro do MP3/M4A, recortada em quadrado (como capa de álbum)."""
    return ["--embed-thumbnail", "--convert-thumbnails", "jpg",
            "--ppa", 'ThumbnailsConvertor+FFmpeg_o:-c:v mjpeg -qmin 1 -qscale:v 2 '
                     '-vf crop="min(iw\\,ih)":"min(iw\\,ih)"']


def build_args(url: str, fmt: str, quality: str, folder: str, temp: str, cut=None) -> list[str]:
    suffix = f" ({tag(cut[0])} a {tag(cut[1])})" if cut else ""
    a = [
        "--no-playlist", "--no-mtime", "--newline", "--progress",
        "--encoding", "utf-8",
        # Baixa numa pasta só deste download; depois o resultado é movido para a pasta do
        # usuário. Assim o yt-dlp nunca reaproveita nem apaga arquivos que já estão lá
        # (ex.: baixar o MP3 de um vídeo cujo MP4 já foi baixado).
        "-P", f"home:{folder}", "-P", f"temp:{temp}",
        "-o", f"%(title).140B{suffix}.%(ext)s",
        "--ffmpeg-location", paths.ffmpeg(),
        "--progress-template",
        f"download:{_PROG} %(progress.downloaded_bytes)s %(progress.total_bytes)s "
        f"%(progress.total_bytes_estimate)s %(progress.eta)s %(progress.speed)s",
        "--print", f"after_move:{_FILE} %(filepath)s",
    ]
    if cut:
        # Baixa só o trecho SEM recodificar durante o download (recodificar deixa a conexão
        # parada e o site derruba o áudio no meio do trecho). Se a conexão cair, o ffmpeg
        # reconecta sozinho. O corte exato (opcional) é feito depois.
        a += ["--download-sections", f"*{_num(cut[0])}-{_num(cut[1])}",
              "--downloader-args",
              "ffmpeg_i:-reconnect 1 -reconnect_streamed 1 -reconnect_on_network_error 1 -reconnect_delay_max 15",
              "--retries", "10"]
    d = paths.deno()
    if d:
        a += ["--js-runtimes", f"deno:{d}"]
    if fmt == "mp4":
        h = re.sub(r"\D", "", quality)
        res = f"res:{h}" if h else "res"
        # H.264 + AAC: abre em qualquer editor (Premiere, CapCut…) e player
        a += ["-f", "bv*+ba/b", "-S", f"{res},vcodec:h264,acodec:m4a",
              "--merge-output-format", "mp4", "--remux-video", "mp4"]
    elif fmt == "mp3":
        k = re.sub(r"\D", "", quality) or "192"
        a += ["-f", "bestaudio/best", "-x", "--audio-format", "mp3", "--audio-quality", f"{k}K",
              "--embed-metadata"] + _cover_art()
    elif fmt == "m4a":
        a += ["-f", "bestaudio[ext=m4a]/bestaudio/best", "-x", "--audio-format", "m4a",
              "--embed-metadata"] + _cover_art()
    else:
        a += ["-f", "bv*+ba/b"]
    return a + ["--", url]


def friendly_error(text: str) -> str:
    m = text.lower()
    if "unsupported url" in m:
        return "Esse link não é suportado."
    if "sign in" in m or "login" in m or "cookies" in m:
        return "O site exige login para esse conteúdo (privado, restrito por idade ou bloqueio temporário)."
    if "429" in m or "rate-limit" in m or "too many requests" in m:
        return "O site bloqueou temporariamente. Tente de novo em alguns minutos."
    if "private" in m:
        return "Esse conteúdo é privado."
    if "unable to resolve" in m or "getaddrinfo" in m or "timed out" in m or "network" in m:
        return "Problema de conexão. Verifique sua internet."
    if "requested format is not available" in m:
        return "Essa qualidade não está disponível. Tente \"Melhor\" ou outro formato."
    return "Não foi possível baixar esse link. Confira se ele abre normalmente e tente de novo mais tarde."


def _fmt_eta(s):
    s = int(s)
    return f"{s // 60}min {s % 60:02d}s" if s >= 60 else f"{s}s"


def _fmt_speed(b):
    return f"{b / 1048576:.1f} MB/s" if b >= 1048576 else f"{b / 1024:.0f} KB/s"


class Download:
    """Um download. run() bloqueia; chame numa thread. cancel() interrompe."""

    def __init__(self, url, fmt, quality, folder, cut=None, exact=False):
        self.url, self.fmt, self.quality, self.folder = url, fmt, quality, folder
        self.cut = tuple(cut) if cut else None          # (início, fim) em segundos
        self.exact = bool(exact) and fmt == "mp4"
        self.proc: subprocess.Popen | None = None
        self.cancelled = False
        self.files: list[str] = []

    def cancel(self):
        self.cancelled = True
        p = self.proc
        if p and p.poll() is None:
            try:
                p.kill()
            except Exception:
                pass

    def _check(self):
        if self.cancelled:
            raise RuntimeError("Download cancelado.")

    def run(self, progress: Callable[[float, str], None]) -> list[str]:
        import shutil, uuid
        Path(self.folder).mkdir(parents=True, exist_ok=True)
        job_dir = Path(paths.temp_dir()) / uuid.uuid4().hex[:10]
        job_dir.mkdir(parents=True)
        self._job_dir = job_dir
        self._stage = "Analisando o link…"
        self._pct = -1.0
        self._pct_at = 0.0
        started = time.time()
        stop = threading.Event()

        # Relógio: a cada segundo mostra há quanto tempo está rodando e quantos MB já
        # vieram (o motor não informa % ao baixar trechos, então medimos os arquivos)
        def ticker():
            while not stop.wait(1.0):
                if time.time() - self._pct_at < 1.5:
                    continue       # o motor está informando a % agora
                sec = int(time.time() - started)
                size = _dir_size(job_dir)
                extra = f"  •  {size / 1048576:.1f} MB".replace(".", ",") if size > 0 else ""
                progress(self._pct, f"{self._stage}  •  ⏱ {sec // 60}:{sec % 60:02d}{extra}")
        tk = threading.Thread(target=ticker, daemon=True)

        def stage(msg, pct=-1.0):
            self._stage, self._pct = msg, pct
            progress(pct, msg)

        try:
            # O motor é atualizado sozinho ao abrir o programa; se ainda estiver
            # atualizando, espera terminar (no máximo 1x por hora)
            if not ENGINE_READY.is_set():
                stage("Terminando de atualizar o motor…")
                ENGINE_READY.wait(120)
            updated_now = auto_update(force=False)
            self._check()
            tk.start()

            def run_once():
                for f in job_dir.iterdir():
                    shutil.rmtree(f, ignore_errors=True) if f.is_dir() else f.unlink(missing_ok=True)
                (job_dir / "partes").mkdir(exist_ok=True)
                self.files = []
                return self._run(stage, progress, str(job_dir), str(job_dir / "partes"))

            try:
                files = run_once()
            except Exception:
                # Falhou? Os sites mudam: força a atualização do motor e tenta mais uma vez
                if self.cancelled or updated_now:
                    raise
                stage("Atualizando o motor e tentando de novo…")
                if not auto_update(force=True):
                    raise
                self._check()
                files = run_once()

            if self.cut:
                # Confere se o áudio cobre o trecho inteiro; se veio cortado, baixa de novo
                want = self.cut[1] - self.cut[0]
                for attempt in (1, 2):
                    short = False
                    for f in files:
                        a = stream_duration(f, "a")
                        if a is not None and a < want - 2.0:
                            short = True
                    if not short or self.cancelled:
                        break
                    stage(f"O áudio veio incompleto, baixando de novo ({attempt}/2)…")
                    files = run_once()
                if self.exact:
                    stop.set()
                    files = [self._exact_cut(f, want, progress) for f in files]
            stop.set()
            self._check()

            stage("Salvando na pasta…")
            final = []
            for f in files:
                dest = _unique(Path(self.folder) / Path(f).name)
                shutil.move(f, dest)
                final.append(str(dest))
            return final
        finally:
            stop.set()
            shutil.rmtree(job_dir, ignore_errors=True)

    def _run(self, stage, progress, home: str, temp: str) -> list[str]:
        cmd = paths.ytdlp() + build_args(self.url, self.fmt, self.quality, home, temp, self.cut)
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     stdin=subprocess.DEVNULL, env=env, **paths.popen_kwargs())
        err_lines: list[str] = []
        c = self.cut
        dl_msg = f"Baixando o trecho {clock(c[0])} a {clock(c[1])}…" if c else "Baixando…"

        def phase(line):
            if "[download] Destination" in line or "time ranges" in line:
                return dl_msg
            if line.startswith("[youtube]") or line.startswith("[info]") or line.startswith("[generic]"):
                return "Lendo a página do vídeo…"
            if "[ExtractAudio]" in line:
                return "Convertendo o áudio…"
            if "[Merger]" in line or "[VideoRemuxer]" in line:
                return "Juntando vídeo e áudio…"
            if "[EmbedThumbnail]" in line or "[ThumbnailsConvertor]" in line:
                return "Colocando a capa…"
            if "[Metadata]" in line:
                return "Gravando informações…"
            return None

        def drain():
            for raw in iter(self.proc.stderr.readline, b""):
                line = raw.decode("utf-8", "replace").rstrip()
                if line:
                    err_lines.append(line)
                    del err_lines[:-60]
                    ph = phase(line)
                    if ph:
                        stage(ph)
        t = threading.Thread(target=drain, daemon=True); t.start()

        stage("Lendo a página do vídeo…")
        parts = 0
        last_pct = 0.0
        for raw in iter(self.proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith(_PROG):
                f = line.split()[1:]
                num = lambda v: float(v) if v not in ("NA", "None", "") else 0.0
                done, total, est, eta, speed = (num(x) for x in (f + ["NA"] * 5)[:5])
                tot = total or est
                if tot and not c:
                    pct = min(100.0, done * 100 / tot)
                    if pct + 5 < last_pct:     # começou a 2ª parte (áudio depois do vídeo)
                        parts += 1
                    last_pct = pct
                    msg = f"Baixando{' o áudio' if parts else ''}… {pct:.0f}%"
                    if speed:
                        msg += f"  •  {_fmt_speed(speed)}"
                    if eta:
                        msg += f"  •  faltam {_fmt_eta(eta)}"
                    self._stage, self._pct, self._pct_at = "Baixando…", pct, time.time()
                    progress(pct, msg)
                    if pct >= 100:
                        stage("Convertendo / juntando…")
                elif self._stage != dl_msg:
                    stage(dl_msg)
            elif line.startswith(_FILE):
                self.files.append(line[len(_FILE):].strip())
            else:
                ph = phase(line)
                if ph and ph != self._stage:
                    stage(ph)
        code = self.proc.wait()
        t.join(2)
        self._check()
        if code != 0:
            detail = next((l for l in reversed(err_lines) if "ERROR" in l), err_lines[-1] if err_lines else "")
            e = RuntimeError(friendly_error(detail))
            e.detail = detail  # type: ignore[attr-defined]
            raise e
        files = [f for f in self.files if os.path.exists(f)]
        if not files:
            raise RuntimeError("O download terminou, mas nenhum arquivo foi encontrado.")
        return files

    def _exact_cut(self, f: str, duration: float, progress) -> str:
        """
        O trecho baixado começa no quadro-chave mais próximo; aqui ele é recortado no ponto
        exato e o áudio é ajustado para cobrir o vídeo inteiro (sem buracos).
        """
        src = Path(f)
        out = src.with_name("corte_exato.mp4")
        progress(0, "Cortando no ponto exato…")
        cmd = [paths.ffmpeg(), "-y", "-v", "error", "-i", str(src),
               "-map", "0:v:0?", "-map", "0:a:0?", "-t", _num(duration),
               "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p",
               "-c:a", "aac", "-b:a", "192k", "-af", "aresample=async=1:first_pts=0",
               "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", str(out)]
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     stdin=subprocess.DEVNULL, **paths.popen_kwargs())
        total = duration * 1_000_000
        for raw in iter(self.proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith("out_time_us="):
                try:
                    pct = max(0, min(99, int(int(line[12:]) * 100 / total)))
                    progress(pct, f"Cortando no ponto exato… {pct}%")
                except ValueError:
                    pass
        code = self.proc.wait()
        self._check()
        if code == 0 and out.exists() and out.stat().st_size > 0:
            final = src.with_suffix(".mp4")
            src.unlink(missing_ok=True)
            out.replace(final)
            return str(final)
        out.unlink(missing_ok=True)   # se falhar, fica com o trecho como veio (só alguns quadros a mais)
        return f


def _dir_size(d: Path) -> int:
    n = 0
    for root, _, fs in os.walk(d):
        for x in fs:
            try:
                n += os.path.getsize(os.path.join(root, x))
            except OSError:
                pass
    return n


def stream_duration(f: str, kind: str) -> float | None:
    """Duração real de uma faixa ("a" = áudio, "v" = vídeo), em segundos."""
    try:
        r = subprocess.run([paths.ffmpeg(), "-hide_banner", "-i", f, "-map", f"0:{kind}:0",
                            "-c", "copy", "-f", "null", "-"],
                           capture_output=True, timeout=300, **paths.popen_kwargs())
    except Exception:
        return None
    if r.returncode != 0:
        return None
    m = re.findall(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr.decode("utf-8", "replace"))
    if not m:
        return None
    h, mi, se = m[-1]
    return int(h) * 3600 + int(mi) * 60 + float(se)


def _unique(p: Path) -> Path:
    if not p.exists():
        return p
    i = 2
    while True:
        q = p.with_name(f"{p.stem} ({i}){p.suffix}")
        if not q.exists():
            return q
        i += 1


# ------------------------------------------------------------- atualização do motor

ENGINE_READY = threading.Event()
ENGINE_READY.set()
_UPDATE_LOCK = threading.Lock()


def auto_update(force: bool = False) -> bool:
    """
    Atualiza o yt-dlp. Sem force, só confere se faz mais de 1 hora da última vez.
    Devolve True se baixou uma versão nova. Nunca impede o download: sem internet
    ou com o GitHub fora do ar, segue com o motor atual.
    """
    with _UPDATE_LOCK:
        now = time.time()
        if not force and now - float(paths.config().get("engine_checked", 0)) < 3600:
            return False
        cmd = paths.ytdlp()
        if len(cmd) > 1:   # rodando como módulo python (modo de desenvolvimento)
            return False
        try:
            r = subprocess.run(cmd + ["-U"], capture_output=True, timeout=180, **paths.popen_kwargs())
            out = (r.stdout + r.stderr).decode("utf-8", "replace").lower()
            paths.save_config(engine_checked=now)
            return r.returncode == 0 and "updated yt-dlp to" in out
        except Exception:
            return False


def update_in_background():
    """Chamado ao abrir o programa: atualiza o motor sem atrapalhar ninguém."""
    ENGINE_READY.clear()

    def work():
        try:
            auto_update(force=False)
        finally:
            ENGINE_READY.set()
    threading.Thread(target=work, daemon=True).start()


def engine_version() -> str:
    try:
        r = subprocess.run(paths.ytdlp() + ["--version"], capture_output=True, timeout=30, **paths.popen_kwargs())
        return r.stdout.decode().strip()
    except Exception:
        return "?"
