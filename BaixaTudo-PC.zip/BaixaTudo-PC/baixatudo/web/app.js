"use strict";
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

async function api(path, body) {
  const opt = { headers: { "X-BT-Token": window.BT_TOKEN } };
  if (body !== undefined) {
    opt.method = "POST";
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `Erro ${r.status}`);
  return j;
}

let toastTimer;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("on");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("on"), 3200);
}

function seg(el, value, onChange) {
  const set = (v) => {
    el.querySelectorAll("button").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.v === v)));
    el.dataset.value = v;
  };
  el.addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    set(b.dataset.v);
    onChange && onChange(b.dataset.v);
  });
  set(value);
  return set;
}

const fmtTime = (s) => {
  s = Math.max(0, s);
  const m = Math.floor(s / 60);
  return `${m}:${(s - m * 60).toFixed(1).padStart(4, "0")}`;
};

/* ============================== navegação */
function show(view) {
  $$(".nav").forEach((b) => {
    const on = b.dataset.view === view;
    b.classList.toggle("on", on);
    if (on) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current");
  });
  $$(".view").forEach((v) => v.classList.toggle("on", v.id === `view-${view}`));
}
$$(".nav").forEach((b) => b.addEventListener("click", () => show(b.dataset.view)));

/* ============================== baixar */
let STATE = {};
const FMT_HINT = {
  mp4: "Vídeo H.264 + AAC: abre em qualquer editor e player.",
  mp3: "Só o áudio, convertido para MP3.",
  m4a: "Só o áudio, sem perda (mais rápido que MP3).",
  original: "Melhor qualidade que o site oferecer, sem converter (pode vir em WebM/MKV).",
};

function fillQuality(fmt, wanted) {
  const list = STATE.formats[fmt] || [];
  const sel = $("#quality");
  sel.innerHTML = list.map((q) => `<option>${q}</option>`).join("");
  $("#qualityField").hidden = list.length === 0;
  if (wanted && list.includes(wanted)) sel.value = wanted;
  else if (fmt === "mp3") sel.value = "192 kbps";
  $("#fmtHint").textContent = FMT_HINT[fmt];
  $("#subsCheckWrap").hidden = !(fmt === "mp4" || fmt === "original");
}

const extractUrl = (t) => ((t || "").match(/https?:\/\/\S+/) || [""])[0].replace(/[.,)"']+$/, "");

async function pasteLink(silent) {
  try {
    const { text } = await api("/api/clipboard", {});
    const u = extractUrl(text);
    if (u) { $("#url").value = u; return true; }
    if (!silent) toast("Não há nenhum link copiado.");
  } catch (e) { if (!silent) toast(e.message); }
  return false;
}

let lastAutoPaste = "";
window.addEventListener("focus", async () => {
  // Colar automático: ao voltar para a janela com um link novo copiado
  if ($("#url").value || !$("#view-baixar").classList.contains("on")) return;
  try {
    const u = extractUrl((await api("/api/clipboard", {})).text);
    if (u && u !== lastAutoPaste) { lastAutoPaste = u; $("#url").value = u; $("#url").select(); }
  } catch {}
});

$("#btnPaste").addEventListener("click", () => pasteLink(false));
$("#btnFolder").addEventListener("click", async () => {
  const { path } = await api("/api/pick-folder", { initial: $("#folder").value });
  if (path) $("#folder").value = path;
});

$("#dlForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = extractUrl($("#url").value);
  if (!url) { toast("Cole um link que comece com http."); $("#url").focus(); return; }
  const fmt = $("#fmt").dataset.value;
  try {
    await api("/api/download", {
      url, format: fmt, quality: $("#qualityField").hidden ? "" : $("#quality").value,
      folder: $("#folder").value.trim(), removeSubs: $("#removeSubs").checked,
    });
    $("#url").value = "";
    lastAutoPaste = url;
    $("#url").focus();
    pollJobs();
  } catch (err) { toast(err.message); }
});

$("#btnClear").addEventListener("click", async () => { await api("/api/clear", {}); pollJobs(); });

$("#btnUpdate").addEventListener("click", async (e) => {
  const b = e.currentTarget;
  b.disabled = true; b.textContent = "Atualizando…";
  try { toast((await api("/api/update", {})).message); refreshEngine(); }
  catch (err) { toast(err.message); }
  b.disabled = false; b.textContent = "Atualizar motor";
});

async function refreshEngine() {
  try { $("#engineVer").textContent = "Motor: yt-dlp " + (await api("/api/engine")).version; } catch {}
}

/* ============================== lista de tarefas */
const handled = new Set();
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const isVideo = (f) => /\.(mp4|mkv|webm|mov|m4v)$/i.test(f);

function jobRow(j) {
  const li = document.createElement("li");
  li.className = `job ${j.status}`;
  const file = j.files[0];
  let acts = "";
  if (j.status === "running") acts = `<button class="btn ghost" data-a="cancel">Cancelar</button>`;
  if (j.status === "done" && file) {
    acts = `<button class="btn ghost" data-a="open">Abrir</button><button class="btn ghost" data-a="show">Mostrar na pasta</button>`;
    if (j.kind === "download" && isVideo(file)) acts += `<button class="btn ghost" data-a="subs">Remover legenda</button>`;
  }
  const pct = j.progress < 0 ? 30 : j.progress;
  li.innerHTML = `
    <div class="t" title="${esc(file || j.title)}">${esc(file ? file.split(/[\\/]/).pop() : j.title)}</div>
    <div class="acts">${acts}</div>
    <div class="m">${esc(j.message)}</div>
    ${j.status === "running" ? `<div class="bar ${j.progress < 0 ? "ind" : ""}"><span style="width:${pct}%"></span></div>` : ""}
    ${j.status === "error" && j.detail ? `<div class="det">${esc(j.detail)}</div>` : ""}`;
  li.addEventListener("click", async (e) => {
    const a = e.target.closest("[data-a]")?.dataset.a;
    if (!a) return;
    if (a === "cancel") await api("/api/cancel", { id: j.id });
    if (a === "open") await api("/api/open", { path: file });
    if (a === "show") await api("/api/show", { path: file });
    if (a === "subs") { show("legenda"); openVideo(file); }
    pollJobs();
  });
  return li;
}

let pollTimer;
async function pollJobs() {
  clearTimeout(pollTimer);
  try {
    const jobs = await api("/api/jobs");
    const dl = jobs.filter((j) => j.kind === "download");
    const rm = jobs.filter((j) => j.kind === "remove");
    $("#jobs").replaceChildren(...dl.map(jobRow));
    $("#jobsEmpty").hidden = dl.length > 0;
    $("#subJobs").replaceChildren(...rm.map(jobRow));
    for (const j of jobs) {
      if (j.status === "running" || handled.has(j.id)) continue;
      handled.add(j.id);
      if (!STATE.loaded) continue;
      if (j.status === "done") {
        toast(`Pronto: ${j.files[0].split(/[\\/]/).pop()}`);
        if (j.kind === "download" && j.extra.removeSubs && isVideo(j.files[0])) { show("legenda"); openVideo(j.files[0]); }
      }
    }
    STATE.loaded = true;
    const busy = jobs.some((j) => j.status === "running");
    pollTimer = setTimeout(pollJobs, busy ? 500 : 2000);
  } catch {
    pollTimer = setTimeout(pollJobs, 2000);
  }
}

// avisa o programa quando a janela fecha (ele encerra sozinho se não houver nada rodando)
window.addEventListener("pagehide", () => navigator.sendBeacon(`/api/bye?k=${window.BT_TOKEN}`));
window.addEventListener("beforeunload", (e) => {
  if ($$(".job.running").length) { e.preventDefault(); e.returnValue = ""; }
});

/* ============================== remover legenda */
const V = { path: null, info: null, t: 0, box: [0.05, 0.72, 0.95, 0.84], previewing: false };
const MODE_HINT = {
  precisa: "Detecta só as letras paradas na tela e recupera o fundo real de outros quadros. Melhor resultado.",
  forte: "Igual à Precisa, mas pega também textos fracos, finos ou com sombra.",
  rapida: "Apaga o retângulo inteiro com um borrão. Bem rápida, resultado simples.",
};
const frameUrl = (t, w) => `/api/frame?k=${window.BT_TOKEN}&path=${encodeURIComponent(V.path)}&t=${t.toFixed(3)}${w ? `&w=${w}` : ""}`;

async function pickVideo() {
  const { path } = await api("/api/pick-video", {});
  if (path) openVideo(path);
}
$("#btnPickVideo").addEventListener("click", pickVideo);
$("#btnPickVideo2").addEventListener("click", pickVideo);
$("#btnOpenPath").addEventListener("click", () => {
  const p = $("#videoPath").value.trim().replace(/^"|"$/g, "");
  if (p) openVideo(p);
});

async function openVideo(path) {
  try {
    const info = await api("/api/video/info", { path });
    Object.assign(V, { path, info, previewing: false });
    $("#vidName").textContent = `${info.name}, ${info.width}×${info.height}, ${fmtTime(info.duration)}`;
    $("#subEmpty").hidden = true;
    $("#subEditor").hidden = false;
    buildStrip();
    seek(info.duration / 3, true);
  } catch (e) {
    toast("Não consegui abrir esse vídeo: " + e.message);
  }
}

function buildStrip() {
  const n = Math.max(6, Math.min(14, Math.round($("#timeline").clientWidth / 80)));
  const d = V.info.duration;
  $("#strip").replaceChildren(...Array.from({ length: n }, (_, i) => {
    const img = new Image();
    img.loading = "lazy";
    img.alt = "";
    img.src = frameUrl(d * (i + 0.5) / n, 200);
    return img;
  }));
}

function placePlayhead() {
  const tl = $("#timeline");
  const pad = 14, w = tl.clientWidth - pad * 2;
  $("#playhead").style.left = `${pad + (V.t / (V.info.duration || 1)) * w}px`;
  $("#tc").textContent = fmtTime(V.t);
}

let frameTimer;
function seek(t, now) {
  V.t = Math.max(0, Math.min(t, (V.info.duration || 0) - 0.05));
  placePlayhead();
  setPreview(false);
  clearTimeout(frameTimer);
  frameTimer = setTimeout(() => { $("#frame").src = frameUrl(V.t); }, now ? 0 : 120);
}

(function timelineDrag() {
  const tl = $("#timeline");
  const at = (e) => {
    const r = tl.getBoundingClientRect();
    return ((e.clientX - r.left - 14) / (r.width - 28)) * V.info.duration;
  };
  tl.addEventListener("pointerdown", (e) => {
    if (!V.info) return;
    tl.setPointerCapture(e.pointerId);
    seek(at(e));
    const move = (ev) => seek(at(ev));
    const up = () => { tl.removeEventListener("pointermove", move); tl.removeEventListener("pointerup", up); };
    tl.addEventListener("pointermove", move);
    tl.addEventListener("pointerup", up);
  });
  window.addEventListener("resize", () => { if (V.info) { placePlayhead(); placeSel(); } });
})();

/* ---- retângulo da legenda */
function placeSel() {
  const img = $("#frame");
  const [l, t, r, b] = V.box;
  const s = $("#sel").style;
  s.left = `${l * img.clientWidth}px`; s.top = `${t * img.clientHeight}px`;
  s.width = `${(r - l) * img.clientWidth}px`; s.height = `${(b - t) * img.clientHeight}px`;
}
$("#frame").addEventListener("load", placeSel);

function saveBox() { setPreview(false); }

(function selDrag() {
  const sel = $("#sel"), img = $("#frame"), viewer = $("#viewer");
  const MIN = 0.02;
  let start = null;
  const onDown = (e, mode) => {
    e.preventDefault(); e.stopPropagation();
    start = { mode, x: e.clientX, y: e.clientY, box: [...V.box] };
    viewer.setPointerCapture(e.pointerId);
  };
  sel.addEventListener("pointerdown", (e) => onDown(e, e.target.dataset.h || "move"));
  // clicar fora do retângulo leva ele para lá
  viewer.addEventListener("pointerdown", (e) => {
    if (e.target !== img || V.previewing) return;
    const r = img.getBoundingClientRect();
    const cx = (e.clientX - r.left) / r.width, cy = (e.clientY - r.top) / r.height;
    const [l, t, rr, b] = V.box, w = rr - l, h = b - t;
    const nl = Math.min(Math.max(cx - w / 2, 0), 1 - w), nt = Math.min(Math.max(cy - h / 2, 0), 1 - h);
    V.box = [nl, nt, nl + w, nt + h];
    placeSel(); saveBox();
    onDown(e, "move");
  });
  viewer.addEventListener("pointermove", (e) => {
    if (!start) return;
    const dx = (e.clientX - start.x) / img.clientWidth, dy = (e.clientY - start.y) / img.clientHeight;
    let [l, t, r, b] = start.box;
    const m = start.mode;
    if (m === "move") {
      const w = r - l, h = b - t;
      l = Math.min(Math.max(l + dx, 0), 1 - w); t = Math.min(Math.max(t + dy, 0), 1 - h);
      r = l + w; b = t + h;
    } else {
      if (m.includes("w")) l = Math.min(Math.max(l + dx, 0), r - MIN);
      if (m.includes("e")) r = Math.max(Math.min(r + dx, 1), l + MIN);
      if (m.includes("n")) t = Math.min(Math.max(t + dy, 0), b - MIN);
      if (m.includes("s")) b = Math.max(Math.min(b + dy, 1), t + MIN);
    }
    V.box = [l, t, r, b];
    placeSel();
  });
  const end = () => { if (start) { start = null; saveBox(); } };
  viewer.addEventListener("pointerup", end);
  viewer.addEventListener("pointercancel", end);
  // teclado: setas movem, Shift+setas mudam o tamanho
  sel.addEventListener("keydown", (e) => {
    const k = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
    if (!k) return;
    e.preventDefault();
    const st = 0.01;
    let [l, t, r, b] = V.box;
    if (e.shiftKey) { r = Math.min(1, Math.max(l + MIN, r + k[0] * st)); b = Math.min(1, Math.max(t + MIN, b + k[1] * st)); }
    else {
      const w = r - l, h = b - t;
      l = Math.min(Math.max(l + k[0] * st, 0), 1 - w); t = Math.min(Math.max(t + k[1] * st, 0), 1 - h);
      r = l + w; b = t + h;
    }
    V.box = [l, t, r, b]; placeSel(); saveBox();
  });
})();

/* ---- prévia e processamento */
function setPreview(on, src) {
  V.previewing = on;
  $("#viewer").classList.toggle("previewing", on);
  $("#previewBadge").hidden = !on;
  $("#btnPreview").textContent = on ? "Editar área" : "Ver prévia";
  if (on && src) $("#frame").src = src;
  else if (!on && V.path && $("#frame").dataset.prev === "1") $("#frame").src = frameUrl(V.t);
  $("#frame").dataset.prev = on ? "1" : "0";
}

$("#btnPreview").addEventListener("click", async () => {
  if (V.previewing) { setPreview(false); return; }
  const mode = $("#mode").dataset.value;
  $("#viewerBusyText").textContent = mode === "rapida" ? "Gerando prévia…" : "Processando 3 segundos em volta deste ponto…";
  $("#viewerBusy").hidden = false;
  $("#btnPreview").disabled = true;
  try {
    const { image } = await api("/api/video/preview", { path: V.path, box: V.box, mode, t: V.t });
    setPreview(true, image);
  } catch (e) { toast("Falha na prévia: " + e.message); }
  $("#viewerBusy").hidden = true;
  $("#btnPreview").disabled = false;
});

$("#btnRemove").addEventListener("click", async () => {
  try {
    await api("/api/video/remove", {
      path: V.path, box: V.box, mode: $("#mode").dataset.value, quality: $("#subQuality").value,
    });
    toast("Removendo a legenda. O arquivo novo fica na mesma pasta do vídeo.");
    await pollJobs();
    $("#subJobs").scrollIntoView({ behavior: "smooth", block: "nearest" });
  } catch (e) { toast(e.message); }
});

/* ============================== início */
(async function init() {
  STATE = await api("/api/state");
  seg($("#fmt"), STATE.format || "mp4", (v) => fillQuality(v));
  fillQuality(STATE.format || "mp4", STATE.quality);
  $("#folder").value = STATE.folder;
  $("#removeSubs").checked = !!STATE.removeSubs;
  seg($("#mode"), STATE.subMode || "precisa", (v) => { $("#modeHint").textContent = MODE_HINT[v]; setPreview(false); });
  $("#modeHint").textContent = MODE_HINT[STATE.subMode || "precisa"];
  $("#subQuality").value = STATE.subQuality || "alta";
  if (Array.isArray(STATE.subBox) && STATE.subBox.length === 4) V.box = STATE.subBox;
  refreshEngine();
  pollJobs();
  $("#url").focus();
})();
