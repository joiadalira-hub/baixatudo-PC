"""Onde ficam os programas auxiliares (yt-dlp, ffmpeg, ffprobe, deno) e as configurações."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

IS_WIN = sys.platform.startswith("win")
EXE = ".exe" if IS_WIN else ""


def app_dir() -> Path:
    """Pasta gravável do usuário (%LOCALAPPDATA%\\BaixaTudo no Windows)."""
    if IS_WIN:
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    d = base / "BaixaTudo"
    d.mkdir(parents=True, exist_ok=True)
    return d


def bundled_bin() -> Path | None:
    """Pasta 'bin' que vai junto com o .exe (PyInstaller) ou ao lado do código."""
    if getattr(sys, "frozen", False):
        p = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent)) / "bin"
    else:
        p = Path(__file__).resolve().parent.parent / "bin"
    return p if p.is_dir() else None


def _find(name: str) -> str | None:
    b = bundled_bin()
    if b and (b / f"{name}{EXE}").exists():
        return str(b / f"{name}{EXE}")
    return shutil.which(name)


def ffmpeg() -> str:
    return _find("ffmpeg") or "ffmpeg"


def ffprobe() -> str:
    return _find("ffprobe") or "ffprobe"


def deno() -> str | None:
    return _find("deno")


def ytdlp() -> list[str]:
    """
    Comando do yt-dlp. O executável que vem com o programa é copiado para a pasta do
    usuário na primeira execução, para poder se atualizar sozinho (yt-dlp -U).
    """
    b = bundled_bin()
    if b and (b / f"yt-dlp{EXE}").exists():
        local = app_dir() / "bin" / f"yt-dlp{EXE}"
        if not local.exists():
            local.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(b / f"yt-dlp{EXE}", local)
        return [str(local)]
    w = shutil.which("yt-dlp")
    if w:
        return [w]
    return [sys.executable, "-m", "yt_dlp"]


def popen_kwargs() -> dict:
    """No Windows, não abre janelas pretas de console para cada processo."""
    if IS_WIN:
        return {"creationflags": 0x08000000}  # CREATE_NO_WINDOW
    return {}


# ---------------------------------------------------------------- configurações

_CFG = None


def _cfg_path() -> Path:
    return app_dir() / "config.json"


def config() -> dict:
    global _CFG
    if _CFG is None:
        try:
            _CFG = json.loads(_cfg_path().read_text("utf-8"))
        except Exception:
            _CFG = {}
    return _CFG


def save_config(**kv):
    c = config()
    c.update(kv)
    try:
        _cfg_path().write_text(json.dumps(c, ensure_ascii=False, indent=2), "utf-8")
    except Exception:
        pass


def temp_dir() -> str:
    d = app_dir() / "temp"
    d.mkdir(parents=True, exist_ok=True)
    return str(d)


def default_download_dir() -> str:
    d = Path.home() / "Downloads" / "BaixaTudo"
    return str(d)


def open_file(path: str):
    if IS_WIN:
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def show_in_folder(path: str):
    """Abre o Explorador com o arquivo já selecionado."""
    p = Path(path)
    if IS_WIN:
        if p.is_file():
            subprocess.Popen(["explorer", "/select,", str(p)])
        else:
            subprocess.Popen(["explorer", str(p)])
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(p)] if p.is_file() else ["open", str(p)])
    else:
        subprocess.Popen(["xdg-open", str(p.parent if p.is_file() else p)])
