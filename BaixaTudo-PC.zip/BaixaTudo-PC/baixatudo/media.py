"""Informações e quadros de um vídeo (via ffprobe/ffmpeg)."""
from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass

import cv2
import numpy as np

from . import paths


@dataclass
class VideoInfo:
    path: str
    width: int      # já considerando a rotação (como aparece na tela)
    height: int
    fps: float
    duration: float


def _rate(s: str | None) -> float:
    try:
        n, d = (s or "0/1").split("/")
        return float(n) / float(d) if float(d) else 0.0
    except Exception:
        return 0.0


def probe(path: str) -> VideoInfo:
    r = subprocess.run(
        [paths.ffprobe(), "-v", "error", "-select_streams", "v:0", "-show_entries",
         "stream=width,height,avg_frame_rate,r_frame_rate,nb_frames:stream_side_data=rotation:"
         "stream_tags=rotate:format=duration", "-of", "json", path],
        capture_output=True, **paths.popen_kwargs())
    if r.returncode != 0:
        raise RuntimeError(r.stderr.decode(errors="replace").strip() or "não é um vídeo")
    j = json.loads(r.stdout or b"{}")
    streams = j.get("streams") or []
    if not streams:
        raise RuntimeError("Esse arquivo não tem vídeo.")
    s = streams[0]
    w, h = int(s.get("width", 0)), int(s.get("height", 0))
    rot = 0
    for sd in s.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = int(float(sd["rotation"]))
    if not rot:
        rot = int(float((s.get("tags") or {}).get("rotate", 0) or 0))
    if abs(rot) % 180 == 90:
        w, h = h, w
    duration = float((j.get("format") or {}).get("duration") or 0)
    fps = _rate(s.get("avg_frame_rate")) or _rate(s.get("r_frame_rate")) or 30.0
    fps = min(max(fps, 5.0), 120.0)
    return VideoInfo(path, w, h, fps, duration)


def grab_frame(path: str, t: float) -> np.ndarray | None:
    r = subprocess.run(
        [paths.ffmpeg(), "-hide_banner", "-nostdin", "-ss", f"{max(0.0, t):.3f}", "-i", path,
         "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "pipe:1"],
        capture_output=True, **paths.popen_kwargs())
    if not r.stdout:
        return None
    return cv2.imdecode(np.frombuffer(r.stdout, np.uint8), cv2.IMREAD_COLOR)
