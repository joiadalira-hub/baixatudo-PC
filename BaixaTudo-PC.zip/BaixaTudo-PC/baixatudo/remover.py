"""
Removedor de legendas (mesmo algoritmo da versão Android).

  1. Detecta só as letras dentro da área marcada: o que tem cara de letra
     (miolo claro + contorno escuro) E fica PARADO na tela por alguns quadros.
  2. Rastreia o movimento da câmera e copia o fundo verdadeiro de quadros vizinhos
     em que aquele ponto estava visível.
  3. Cada cópia é conferida com a vizinhança das letras; se não bater (a pessoa se
     mexeu), é descartada — isso evita "fantasmas".
  4. O quadro anterior já limpo também é reaproveitado.
  5. O que nunca aparece é reconstruído pelas bordas (inpainting Telea).

Dois FFmpeg ligados por pipe: decodificador (só a faixa da legenda) -> TextRemover ->
codificador (cola a faixa limpa por cima do vídeo original e mantém o áudio).
"""
from __future__ import annotations

import subprocess
import threading
from dataclasses import dataclass
from typing import Callable, Optional

import cv2
import numpy as np

from . import paths

PRECISE, STRONG, FAST = "precisa", "forte", "rapida"


@dataclass
class Box:
    x0: int
    y0: int
    x1: int
    y1: int


# ----------------------------------------------------------------- matemática

def _compose(b, a):
    return np.array([
        b[0] * a[0] + b[1] * a[3], b[0] * a[1] + b[1] * a[4], b[0] * a[2] + b[1] * a[5] + b[2],
        b[3] * a[0] + b[4] * a[3], b[3] * a[1] + b[4] * a[4], b[3] * a[2] + b[4] * a[5] + b[5]])


def _invert(m):
    det = m[0] * m[4] - m[1] * m[3]
    if abs(det) < 1e-9:
        return None
    i0, i1, i3, i4 = m[4] / det, -m[1] / det, -m[3] / det, m[0] / det
    return np.array([i0, i1, -(i0 * m[2] + i1 * m[5]), i3, i4, -(i3 * m[2] + i4 * m[5])])


def _ellipse(k):
    return cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))


class TextRemover:
    def __init__(self, frame_w: int, frame_h: int, box: Box, strong: bool = False):
        W, H = frame_w, frame_h
        bx0 = min(max(box.x0, 0), W - 8); by0 = min(max(box.y0, 0), H - 8)
        bx1 = min(max(box.x1, bx0 + 8), W); by1 = min(max(box.y1, by0 + 8), H)
        box_h = by1 - by0
        self.strong = strong

        # Faixa lida do vídeo (tudo par: o FFmpeg arredonda recortes ímpares em yuv420p)
        margin = max(40, box_h)
        self.sx = max(0, bx0 - margin) & ~1
        self.sy = max(0, by0 - margin) & ~1
        self.sw = (min(W, bx1 + margin) - self.sx) & ~1
        self.sh = (min(H, by1 + margin) - self.sy) & ~1
        sw, sh = self.sw, self.sh

        # Área de trabalho = caixa + borda (coordenadas da faixa)
        pad = 12
        self.wx0 = max(0, bx0 - self.sx - pad); self.wy0 = max(0, by0 - self.sy - pad)
        self.wx1 = min(sw, bx1 - self.sx + pad); self.wy1 = min(sh, by1 - self.sy + pad)
        self.ww, self.wh = self.wx1 - self.wx0, self.wy1 - self.wy0
        self.bxr = (bx0 - self.sx - self.wx0, by0 - self.sy - self.wy0, bx1 - bx0, by1 - by0)
        self.frame_bytes = sw * sh * 3

        per_frame = self.frame_bytes + sw * sh + sw * sh // 4 + self.ww * self.wh * 2
        self.window = max(6, min(30, (400 * 1024 * 1024) // per_frame // 2))
        self.offsets = [k for k in (1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 22, 26, 30) if k <= self.window]

        self.thr = 24 if strong else 40
        mk = max(9, min(61, int(box_h * 0.45))) | 1
        dk = (max(5, H // 180) + (4 if strong else 0)) | 1
        self.rad = max(4.0, min(10.0, H / 180))
        self.mK, self.nK, self.dK = _ellipse(mk), _ellipse(dk), _ellipse(dk)
        self.cK = _ellipse((3 * dk) | 1)
        self.oK = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
        self.open3, self.close7 = _ellipse(3), _ellipse(7)

        self.stab_frames, self.stab_max = 3, 15
        self.sig4 = max(6.0, H / 64) / 4
        self.err_max, self.den_min = 10.0, 0.002

        hs = (sw // 2, sh // 2)
        self.half_size = hs
        self.track = np.full((hs[1], hs[0]), 255, np.uint8)
        self.track[(by0 - self.sy) // 2:(by1 - self.sy) // 2 + 1, (bx0 - self.sx) // 2:(bx1 - self.sx) // 2 + 1] = 0
        self.ones = np.full((sh, sw), 255, np.uint8)

        self.frames: dict[int, list] = {}  # i -> [bgr, half, mask, notMask, workGray, raw, final]
        self.steps: dict[int, Optional[np.ndarray]] = {}

    # ------------------------------------------------------------- detecção

    @staticmethod
    def _reconstruct(seed, limit, it=6):
        k = np.ones((3, 3), np.uint8); cur = seed
        for _ in range(it):
            nxt = cv2.bitwise_and(cv2.dilate(cur, k, iterations=2), limit)
            if np.array_equal(nxt, cur):
                break
            cur = nxt
        return cur

    def _detect(self, g):
        top = cv2.morphologyEx(g, cv2.MORPH_TOPHAT, self.mK)
        blk = cv2.morphologyEx(g, cv2.MORPH_BLACKHAT, self.mK)
        bright = ((top > self.thr) * 255).astype(np.uint8)
        dark = ((blk > self.thr) * 255).astype(np.uint8)
        if self.strong:
            m = cv2.morphologyEx(cv2.bitwise_or(bright, dark), cv2.MORPH_OPEN, self.oK)
        else:
            m = cv2.bitwise_and(bright, cv2.dilate(dark, self.nK))   # miolo claro + contorno escuro
            m = cv2.morphologyEx(m, cv2.MORPH_OPEN, self.oK)
            m = self._reconstruct(m, bright)
            around = cv2.dilate(m, self.cK)
            m = cv2.bitwise_or(m, cv2.bitwise_and(around, cv2.bitwise_or(bright, dark)))
        o = np.zeros_like(m); x, y, w, h = self.bxr
        o[y:y + h, x:x + w] = m[y:y + h, x:x + w]
        return o

    def _full_not(self, m):
        full = np.zeros((self.sh, self.sw), np.uint8)
        full[self.wy0:self.wy1, self.wx0:self.wx1] = m
        return cv2.bitwise_not(full)

    def _finalize(self, i):
        f = self.frames.get(i)
        if f is None or f[6]:
            return
        g = f[4].astype(np.int16)

        def maxdiff(rng):
            ds = [np.abs(self.frames[n][4].astype(np.int16) - g) for n in rng if n in self.frames]
            return np.max(ds, 0) if ds else None

        S = self.stab_frames
        a, b = maxdiff(range(i - S, i)), maxdiff(range(i + 1, i + S + 1))
        if a is None and b is None:
            return
        md = b if a is None else a if b is None else np.minimum(a, b)
        stable = (md < self.stab_max).astype(np.uint8) * 255
        m = cv2.bitwise_and(f[5], stable)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, self.open3)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, self.close7)
        m = cv2.dilate(m, self.dK)
        f[2], f[3], f[6] = m, self._full_not(m), True

    # ------------------------------------------------------------- movimento

    def _motion(self, a, b):
        p = cv2.goodFeaturesToTrack(a, 200, 0.01, 5, mask=self.track)
        if p is None or len(p) < 8:
            return None
        q, st, _ = cv2.calcOpticalFlowPyrLK(a, b, p, None, winSize=(15, 15), maxLevel=3)
        ok = st.ravel() == 1
        if ok.sum() < 8:
            return None
        A, inl = cv2.estimateAffinePartial2D(p[ok], q[ok], method=cv2.RANSAC, ransacReprojThreshold=1.0)
        if A is None or inl.sum() < 8:
            return None
        A = A.ravel().copy(); A[2] *= 2; A[5] *= 2
        return A

    def _transform(self, t, n):
        tr = np.array([1., 0, 0, 0, 1, 0])
        if n > t:
            for i in range(t, n):
                s = self.steps.get(i)
                if s is None:
                    return None
                tr = _compose(s, tr)
        else:
            for i in range(t - 1, n - 1, -1):
                s = self.steps.get(i)
                iv = None if s is None else _invert(s)
                if iv is None:
                    return None
                tr = _compose(iv, tr)
        return tr

    # ------------------------------------------------------------- preenchimento

    def _fill(self, outW, rem, cur_mask, cur_gray, src, valid, tr):
        wx0, wy0, ww, wh = self.wx0, self.wy0, self.ww, self.wh
        a, b, c, d, e, f = tr
        M = np.array([[a, b, a * wx0 + b * wy0 + c], [d, e, d * wx0 + e * wy0 + f]])
        fl = cv2.WARP_INVERSE_MAP
        wp = cv2.warpAffine(src, M, (ww, wh), flags=cv2.INTER_LINEAR | fl, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        vl = cv2.warpAffine(valid, M, (ww, wh), flags=cv2.INTER_NEAREST | fl, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        use = cv2.bitwise_and(rem, vl)
        if cv2.countNonZero(use) == 0:
            return
        # verificação de consistência (1/4 da resolução)
        ring = ((cur_mask == 0) & (vl > 0)).astype(np.float32)
        q = (max(1, ww // 4), max(1, wh // 4))
        rs = cv2.resize(ring, q, interpolation=cv2.INTER_AREA)
        ws = cv2.resize(cv2.cvtColor(wp, cv2.COLOR_BGR2GRAY).astype(np.float32) * ring, q, interpolation=cv2.INTER_AREA)
        cs = cv2.resize(cur_gray * ring, q, interpolation=cv2.INTER_AREA)
        err = np.abs(ws - cs) / np.maximum(rs, 1e-3)
        w = (rs > 0.25).astype(np.float32)
        num = cv2.GaussianBlur(err * w, (0, 0), self.sig4)
        den = cv2.GaussianBlur(w, (0, 0), self.sig4)
        e_ = num / np.maximum(den, 1e-4)
        bad = ((e_ > self.err_max) & (den > self.den_min)).astype(np.uint8) * 255
        use[cv2.resize(bad, (ww, wh), interpolation=cv2.INTER_NEAREST) > 0] = 0
        outW[use > 0] = wp[use > 0]
        rem[:] = cv2.subtract(rem, use)

    def _add(self, idx, buf):
        bgr = np.frombuffer(buf, np.uint8).reshape(self.sh, self.sw, 3).copy()
        g = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        half = cv2.resize(g, self.half_size, interpolation=cv2.INTER_AREA)
        gw = g[self.wy0:self.wy1, self.wx0:self.wx1].copy()
        raw = self._detect(gw)
        cons = cv2.dilate(raw, self.dK)   # provisória (conservadora)
        if idx - 1 in self.frames:
            self.steps[idx - 1] = self._motion(self.frames[idx - 1][1], half)
        self.frames[idx] = [bgr, half, cons, self._full_not(cons), gw, raw, False]
        self._finalize(idx - self.stab_frames)

    def _process(self, t, prev):
        bgr, _, m = self.frames[t][:3]
        out = bgr.copy()
        outW = out[self.wy0:self.wy1, self.wx0:self.wx1]
        rem = m.copy()
        total = cv2.countNonZero(rem)
        if not total:
            return out
        cur_gray = cv2.cvtColor(outW, cv2.COLOR_BGR2GRAY).astype(np.float32)
        tiny = total // 500
        for k in self.offsets:
            for n in (t + k, t - k):
                if n not in self.frames:
                    continue
                tr = self._transform(t, n)
                if tr is not None:
                    self._fill(outW, rem, m, cur_gray, self.frames[n][0], self.frames[n][3], tr)
            if cv2.countNonZero(rem) <= tiny:
                break
        if cv2.countNonZero(rem) > tiny and prev is not None:
            tr = self._transform(t, t - 1)
            if tr is not None:
                self._fill(outW, rem, m, cur_gray, prev, self.ones, tr)
        if cv2.countNonZero(rem):
            outW[:] = cv2.inpaint(outW, rem, self.rad, cv2.INPAINT_TELEA)
        return out

    def run(self, stream, on_frame: Callable[[int, np.ndarray], None],
            cancelled: Callable[[], bool] = lambda: False,
            on_buffering: Callable[[int], None] = lambda n: None):
        """Lê quadros BGR24 (sw x sh) de [stream] e entrega cada quadro limpo em on_frame."""
        read, eof, prev, t, flushed = 0, False, None, 0, False
        while not cancelled():
            while not eof and read <= t + self.window and not cancelled():
                buf = _read_exact(stream, self.frame_bytes)
                if buf is None:
                    eof = True
                    break
                self._add(read, buf)
                read += 1
                if t == 0:
                    on_buffering(read)
            if eof and not flushed:
                for i in range(max(0, read - self.stab_frames), read):
                    self._finalize(i)
                flushed = True
            if t >= read or cancelled():
                break
            out = self._process(t, prev)
            on_frame(t, out)
            prev = out
            self.frames.pop(t - self.window, None)
            self.steps.pop(t - self.window - 1, None)
            t += 1
        self.frames.clear(); self.steps.clear()
        return t


def _read_exact(stream, n):
    chunks, got = [], 0
    while got < n:
        b = stream.read(n - got)
        if not b:
            return None
        chunks.append(b); got += len(b)
    return b"".join(chunks) if len(chunks) > 1 else chunks[0]


# ---------------------------------------------------------------- execução

class Cancelled(Exception):
    pass


class _Proc:
    """Processo do FFmpeg com o log de erro sendo coletado numa thread."""

    def __init__(self, args, stdin=False, stdout=False):
        self.p = subprocess.Popen(
            args,
            stdin=subprocess.PIPE if stdin else subprocess.DEVNULL,
            stdout=subprocess.PIPE if stdout else subprocess.DEVNULL,
            stderr=subprocess.PIPE, **paths.popen_kwargs())
        self.log: list[str] = []
        self._t = threading.Thread(target=self._drain, daemon=True)
        self._t.start()

    def _drain(self):
        for line in iter(self.p.stderr.readline, b""):
            self.log.append(line.decode("utf-8", "replace").rstrip())
            if len(self.log) > 300:
                del self.log[:100]

    def last_error(self):
        for line in reversed(self.log):
            if line.strip() and not line.startswith("["):
                return line.strip()[:300]
        return self.log[-1][:300] if self.log else "erro desconhecido"

    def kill(self):
        try:
            self.p.kill()
        except Exception:
            pass

    def wait(self):
        code = self.p.wait()
        self._t.join(2)
        return code


def _fps_str(fps):
    return f"{fps:.3f}"


def _audio_args(path):
    return ["-c:a", "copy"] if path.lower().endswith((".mp4", ".mov", ".m4v", ".3gp")) else ["-c:a", "aac", "-b:a", "192k"]


def delogo_filter(w0, h0, box: Box):
    x = min(max(box.x0, 2), w0 - 20); y = min(max(box.y0, 2), h0 - 20)
    w = min(max(box.x1 - box.x0, 16), w0 - x - 2); h = min(max(box.y1 - box.y0, 16), h0 - y - 2)
    blur = min(max(min(w, h) // 8, 2), 6)
    return (f"[0:v]delogo=x={x}:y={y}:w={w}:h={h},split[m][r];"
            f"[r]crop={w}:{h}:{x}:{y},boxblur={blur}:1[b];[m][b]overlay={x}:{y},format=yuv420p[v]")


class RemoveJob:
    """Roda a remoção de um vídeo inteiro. Chame run() numa thread; cancel() para parar."""

    def __init__(self, info, box: Box, mode: str, out_path: str, crf: int = 16):
        self.info, self.box, self.mode, self.out_path, self.crf = info, box, mode, out_path, crf
        self._procs: list[_Proc] = []
        self._cancel = False

    def cancel(self):
        self._cancel = True
        for p in self._procs:
            p.kill()

    def run(self, progress: Callable[[float, str], None]):
        if self.mode == FAST:
            return self._run_fast(progress)
        return self._run_precise(progress)

    def _encode_args(self):
        return ["-c:v", "libx264", "-preset", "medium", "-crf", str(self.crf), "-pix_fmt", "yuv420p"]

    def _run_fast(self, progress):
        info = self.info
        args = [paths.ffmpeg(), "-hide_banner", "-nostdin", "-y", "-i", info.path,
                "-filter_complex", delogo_filter(info.width, info.height, self.box),
                "-map", "[v]", "-map", "0:a?"] + self._encode_args() + _audio_args(info.path) + \
               ["-movflags", "+faststart", "-progress", "pipe:1", "-nostats", self.out_path]
        p = _Proc(args, stdout=True); self._procs.append(p)
        total_us = max(1, int(info.duration * 1e6))
        for raw in iter(p.p.stdout.readline, b""):
            line = raw.decode(errors="replace").strip()
            if line.startswith("out_time_us="):
                try:
                    pct = min(99.0, int(line.split("=")[1]) * 100 / total_us)
                    progress(pct, f"Removendo legenda… {pct:.0f}%")
                except ValueError:
                    pass
        code = p.wait()
        if self._cancel:
            raise Cancelled()
        if code != 0:
            raise RuntimeError(p.last_error())

    def _run_precise(self, progress):
        import time
        info = self.info
        r = TextRemover(info.width, info.height, self.box, strong=self.mode == STRONG)
        f = _fps_str(info.fps)
        dec = _Proc([paths.ffmpeg(), "-hide_banner", "-nostdin", "-y", "-i", info.path,
                     "-vf", f"fps={f},crop={r.sw}:{r.sh}:{r.sx}:{r.sy}",
                     "-an", "-f", "rawvideo", "-pix_fmt", "bgr24", "pipe:1"], stdout=True)
        enc = _Proc([paths.ffmpeg(), "-hide_banner", "-y", "-i", info.path,
                     "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{r.sw}x{r.sh}", "-framerate", f, "-i", "pipe:0",
                     "-filter_complex",
                     f"[0:v]fps={f},setpts=N/({f}*TB)[b];[1:v]setpts=N/({f}*TB)[o];"
                     f"[b][o]overlay={r.sx}:{r.sy}:eof_action=pass,format=yuv420p[v]",
                     "-map", "[v]", "-map", "0:a?"] + self._encode_args() + _audio_args(info.path) +
                    ["-movflags", "+faststart", self.out_path], stdin=True)
        self._procs += [dec, enc]
        total = max(1, round(info.duration * info.fps))
        state = {"first": 0.0, "ui": 0.0}

        def on_frame(i, frame):
            enc.p.stdin.write(frame.tobytes())
            now = time.time()
            if i == 0:
                state["first"] = now
            if now - state["ui"] > 0.3 or i == 0:
                state["ui"] = now
                pct = min(99.0, i * 100 / total)
                el = now - state["first"]
                speed = i / el if i and el > 0 else 0
                eta = (total - i) / speed if speed else 0
                msg = f"Removendo legenda… {pct:.0f}%  •  quadro {i + 1} de {total}"
                if speed:
                    msg += f"  •  {speed:.1f} q/s  •  faltam {_fmt_eta(eta)}"
                progress(pct, msg)

        write_error = None
        try:
            r.run(dec.p.stdout, on_frame, cancelled=lambda: self._cancel,
                  on_buffering=lambda n: progress(0, f"Analisando os primeiros quadros… ({n})"))
            enc.p.stdin.close()
        except (BrokenPipeError, OSError, ValueError) as e:
            write_error = e
        if self._cancel:
            raise Cancelled()
        progress(99, "Finalizando o vídeo…")
        code = enc.wait(); dec.wait()
        if write_error is not None or code != 0:
            raise RuntimeError(enc.last_error())


def preview(info, box: Box, mode: str, pos: float):
    """Retorna o quadro (BGR) em [pos] segundos já sem a legenda."""
    if mode == FAST:
        out = subprocess.run([paths.ffmpeg(), "-hide_banner", "-nostdin", "-ss", f"{pos:.3f}", "-i", info.path,
                              "-filter_complex", delogo_filter(info.width, info.height, box), "-map", "[v]",
                              "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "pipe:1"],
                             capture_output=True, **paths.popen_kwargs())
        img = cv2.imdecode(np.frombuffer(out.stdout, np.uint8), cv2.IMREAD_COLOR)
        if img is None:
            raise RuntimeError(out.stderr.decode(errors="replace").strip().splitlines()[-1:] or "falha")
        return img
    start = max(0.0, pos - 1.5)
    mid = round((pos - start) * info.fps)
    r = TextRemover(info.width, info.height, box, strong=mode == STRONG)
    f = _fps_str(info.fps)
    full = subprocess.run([paths.ffmpeg(), "-hide_banner", "-nostdin", "-ss", f"{start:.3f}", "-t", "3", "-i", info.path,
                           "-vf", f"fps={f},select='gte(n,{mid})'", "-fps_mode", "passthrough",
                           "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "pipe:1"],
                          capture_output=True, **paths.popen_kwargs())
    base = cv2.imdecode(np.frombuffer(full.stdout, np.uint8), cv2.IMREAD_COLOR)
    if base is None:
        raise RuntimeError("Não consegui ler esse ponto do vídeo.")
    dec = _Proc([paths.ffmpeg(), "-hide_banner", "-nostdin", "-ss", f"{start:.3f}", "-t", "3", "-i", info.path,
                 "-vf", f"fps={f},crop={r.sw}:{r.sh}:{r.sx}:{r.sy}",
                 "-an", "-f", "rawvideo", "-pix_fmt", "bgr24", "pipe:1"], stdout=True)
    got = {}

    def on_frame(i, frame):
        if i >= mid and "s" not in got:
            got["s"] = frame.copy()

    r.run(dec.p.stdout, on_frame, cancelled=lambda: "s" in got)
    dec.kill(); dec.wait()
    s = got.get("s")
    if s is None:
        raise RuntimeError("Não consegui gerar a prévia nesse ponto do vídeo.")
    base[r.sy:r.sy + r.sh, r.sx:r.sx + r.sw] = s
    return base


def _fmt_eta(sec):
    sec = int(sec)
    return f"{sec // 60}min {sec % 60:02d}s" if sec >= 60 else f"{sec}s"
